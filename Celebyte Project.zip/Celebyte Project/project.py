# import required libraries
import time
import database
import random
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# set up browser driver
chromeOptions = Options()
chromeOptions.headless = True

options = webdriver.ChromeOptions()
options.add_experimental_option("excludeSwitches",["ignore-certificate-errors"])
options.add_argument('--disable-gpu')
options.add_argument('--headless')
driver = webdriver.Chrome(executable_path = 'chromedriver_win32/chromedriver.exe',options=options)


driver.get("https://www.celebyte.com/")

driver.maximize_window()


# This function fetch the data and stored into the database
def data():
	try:
		time.sleep(2)
		url = driver.current_url
		
		start_point = url.find('.com') + 5
		
		unique_id = url[start_point:]
		
		celeb_name =  WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'celeb-name')))
		
		celeb_feat =  WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="formBookNow"]/div[1]/div[2]/p')))
		
		lang = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="formBookNow"]/div[1]/ul/li[1]')))
		
		response_time = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="formBookNow"]/div[1]/ul/li[2]')))
		
		video_call_price = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'videoCallOfferPrice')))
		
		video_mes_price = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'videoMessageOfferPrice')))	
		
		text_mes_price = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, 'textMessageOfferPrice')))
		database.insert_actor(celeb_name.text,celeb_feat.text,lang.text,response_time.text,video_call_price.text,video_mes_price.text,text_mes_price.text,unique_id)
	except Exception as e:
		print(e)
	

try:
 	element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.LINK_TEXT, 'Explore From 600+ Celebs')))
 	element.click()
 	time.sleep(5)
 	
 	celeb_slide = driver.find_elements_by_class_name('celeb-slide')
 	
 	# Open Each Celebrity's Profile Present in Profile
 	i = 1
 	while True:
 		time.sleep(2)
 		try:
	 		slide = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, f'//*[@id="div-artist-list"]/div[{i}]'))) 
	 		slide.click()
	 		time.sleep(5)
	 		
	 		data()
	 		
	 		driver.back()
	 		i += 1
	 	except:
	 		break
 	
except Exception as e:
	print(e)
	driver.quit()