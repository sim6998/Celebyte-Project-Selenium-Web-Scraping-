import mysql.connector

conn = mysql.connector.connect(host='localhost',user='root',passwd='',database='celebyte')

# Insert Data into actor table
def insert_actor(celeb_name,celeb_feat,lang,response_time,video_call_price,video_mes_price,text_mes_price,unique_id):
	if conn:
		print('success')
		try:
			cursor = conn.cursor()

			select = f'SELECT * FROM actor WHERE actor_uniqe_id = "{unique_id}"'
			cursor.execute(select)
			

			if cursor.fetchone():
				update = f'UPDATE actor SET full_name = "{celeb_name}", features = "{celeb_feat}", language = "{lang}", response_time = "{response_time}", video_call_price = "{video_call_price}", video_msg_price = "{video_mes_price}", text_msg_price = "{text_mes_price}", new_celeb = "false" WHERE actor_uniqe_id = "{unique_id}"'
				cursor.execute(update)
				conn.commit()
			else:
				print('else selected')
				insert = 'INSERT INTO actor(full_name,features,language,response_time,video_call_price,video_msg_price,text_msg_price,actor_uniqe_id,new_celeb) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)'
				val = (celeb_name,celeb_feat,lang,response_time,video_call_price,video_mes_price,text_mes_price,unique_id,"true")

				cursor.execute(insert,val)
				
				conn.commit()
				
				
				print("Data Inserted Successfully..!!!")

		except Exception as e:
			print(e)
	else:
		print('Error')

